export interface IStoreOptions {
  /**
   * true, clear _inflights at close
   */
  clean?: boolean
}
